This is building directory for AMD-64 architecture.
