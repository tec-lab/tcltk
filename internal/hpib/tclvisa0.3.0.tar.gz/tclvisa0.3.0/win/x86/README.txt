This is building directory for Intel-32 architecture.
